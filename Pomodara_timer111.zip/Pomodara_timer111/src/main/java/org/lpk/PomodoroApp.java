package org.lpk;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PomodoroApp extends Application 
{
    private Label timerLabel;
    private Button startButton;
    private Button stopButton;
    private PomodoroTimer timer;
    private MediaPlayer mediaPlayer;  

    @Override
    public void start(Stage stage) 
    {
        timerLabel=new Label("25:00");
        startButton=new Button("Start");
        stopButton=new Button("Stop"); 
        timer=new PomodoroTimer();
        mediaPlayer=new MediaPlayer();
        startButton.setOnAction(event -> 
        {
            timer.startTimer(timerLabel);
            mediaPlayer.playMusic("relaxing-music.mp3"); 
        });

        stopButton.setOnAction(event -> 
        {
            timer.stopTimer();  
            mediaPlayer.stopMusic();  
        });
        VBox layout=new VBox(20, timerLabel,startButton,stopButton);
        Scene scene=new Scene(layout,300,200);
        stage.setTitle("Pomodoro Timer");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) 
    {
        launch(args);
    }
}
//
package org.lpk;
import javazoom.jl.player.Player;
import java.io.FileInputStream;

public class MediaPlayer 
{
    private Player player;
    public void playMusic(String filePath) 
    {
        try 
        {
            FileInputStream fileInputStream=new FileInputStream("/Users/chaitanya/Downloads/see-you-later-203103.mp3");//add music path ex:/Users /chaitanya/Downloads/music.mp3
            player=new Player(fileInputStream);
            new Thread(()->{ // for playing we should have a separate thread because we created only a class MediaPlayer and in that class "xsplayer" is separate instance
                try 
                {
                    player.play();
                } 
                catch(Exception e) 
                {
                    e.printStackTrace();
                }
            }).start();
        } 
        catch(Exception e) 
        {
            e.printStackTrace();
        }
    }

    public void stopMusic() 
    {
        if(player!=null) 
        {
            player.close();
        }
    }
}
